## 题目名称

Easyvm

### 题目类型

PWN

### 难度

中级

### 题目标签

Pwn、vm

### 题目分值桶

1000

### 提示

- login这么复杂，一定有洞吧
- 越界是vm的经典漏洞

### 作者

DawnAA

### 备注

### 题目描述

Easyvm是一个Easy virtual machine。

